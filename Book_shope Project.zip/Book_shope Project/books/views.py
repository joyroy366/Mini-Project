from django.shortcuts import render, redirect
from .models import Book


def home(request):
    latest_books = Book.objects.all().order_by("-id")[:3]
    context = {
        "latest_books": latest_books
    }
    return render(request,"books/home.html",context)

def book_list(request):
    search = request.GET.get("search")
    if search:
        books = Book.objects.filter(title__icontains=search)
    else:
        books = Book.objects.all()
    context = {
        "books": books
    }
    return render(request,"books/book_list.html",context)



def book_create(request):
    if request.method == "POST":
        data = request.POST
        Book.objects.create(
            title=data["title"],
            author=data["author"],
            rating=data["rating"],
            review=data["review"]
        )
        return redirect("/books/")
    return render(request,"books/book_create.html")



def book_update(request,id):
    book = Book.objects.get(id=id)
    if request.method == "POST":
        data = request.POST

        book.title = data["title"]
        book.author = data["author"]
        book.rating = data["rating"]
        book.review = data["review"]

        book.save()

        return redirect("/books/")

    context = {
        "book": book
    }
    return render(request,"books/book_update.html",context)



def book_delete(request,id):
    book = Book.objects.get(id=id)
    book.delete()
    return redirect("/books/")