from django.urls import path
from .views import *

urlpatterns = [

    path('',home,name="home"),
    path('books/',book_list,name="books"),
    path('create/',book_create,name="create"),
    path('update/<int:id>/',book_update,name="update"),
    path('delete/<int:id>/',book_delete,name="delete"),

]