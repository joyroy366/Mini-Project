from django.contrib import admin
from .models import Donor, Payment, Expense, ExpenseCategory

# Register your models here.
@admin.register(Donor)
class DonorAdmin(admin.ModelAdmin):
    list_display = ("name", "group", "area", "expected_amount")
    list_filter = ("group",)
    search_fields = ("name", "phone", "address")
    ordering = ("name",)


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("receipt_no", "donor", "amount", "date", "collected_by")
    search_fields = ("receipt_no", "donor__name")
    list_filter = ("date",)
    ordering = ("-date",)


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ("date", "category", "amount", "paid_to", "paid_by")
    list_filter = ("category", "date")
    search_fields = ("paid_to", "paid_by")


@admin.register(ExpenseCategory)
class ExpenseCategoryAdmin(admin.ModelAdmin):
    list_display = ("name",)