import re
from django import forms
from datetime import date
from .models import Donor,Payment, Expense, ExpenseCategory

class QuickPaymentForm(forms.Form):
    donor = forms.ModelChoiceField(
        queryset=Donor.objects.all().order_by("name"),
        required=False,
        label="আগের ডোনার (থাকলে সিলেক্ট করুন)"
    )

    group = forms.ChoiceField(
        choices=Donor.GROUP_CHOICES,
        required=False,
        label="ডোনার টাইপ (Local/Outside)"
    )

    name = forms.CharField(required=False, label="ডোনারের নাম")
    phone = forms.CharField(required=False, label="ফোন (যদি থাকে)")

    # Local হলে এখানে এলাকার নাম লিখবে
    address = forms.CharField(
        required=False,
        label="Local Area (পাড়া/এলাকার নাম)",
        widget=forms.Textarea(attrs={"rows": 2, "placeholder": "Local হলে এখানে এলাকার নাম লিখুন"})
    )

    # Outside হলে এখানে district
    outside_area = forms.CharField(
        required=False,
        label="Outside হলে Home District",
        widget=forms.TextInput(attrs={"placeholder": "যেমন: Cumilla"})
    )

    expected_amount = forms.DecimalField(required=False, label="Expected Amount", min_value=0)

    amount = forms.DecimalField(label="Payment Amount (কত টাকা)", min_value=0)
    receipt_no = forms.CharField(required=False, label="Receipt No (না দিলে Auto হবে)")

    def clean(self):
        cleaned = super().clean()
        donor = cleaned.get("donor")

        # donor select করা থাকলে donor info লাগবে না
        if donor:
            return cleaned

        # নতুন donor হলে এগুলো দরকার
        group = cleaned.get("group")
        name = cleaned.get("name")
        if not group:
            self.add_error("group", "নতুন ডোনার হলে Local/Outside সিলেক্ট করুন")
        if not name:
            self.add_error("name", "নতুন ডোনার হলে নাম দিন")

        # Local হলে address দরকার, Outside হলে outside_area দরকার
        if group == Donor.LOCAL and not (cleaned.get("address") or "").strip():
            self.add_error("address", "Local হলে এলাকার নাম (address) দিন")
        if group == Donor.OUTSIDE and not (cleaned.get("outside_area") or "").strip():
            self.add_error("outside_area", "Outside হলে Home District দিন")

        return cleaned



class ExpenseCategoryForm(forms.ModelForm):
    class Meta:
        model = ExpenseCategory
        fields = ["name"]
        labels = {"name": "ক্যাটাগরি নাম (যেমন: খাবার/লাইট/ডেকোরেশন)"}
        widgets = {"name": forms.TextInput(attrs={"placeholder":"নতুন ক্যাটাগরি লিখুন"})}

class ExpenseForm(forms.ModelForm):
    # টাইপ করার জন্য text field
    category_name = forms.CharField(
        label="Category (খরচের ধরন)",
        widget=forms.TextInput(attrs={
            "placeholder": "যেমন: Food / Decoration / Light",
            "list": "categoryList"   # template এ datalist id
        })
    )

    class Meta:
        model = Expense
        # category বাদ, কারণ আমরা category_name থেকে সেট করবো
        fields = ["amount", "paid_to", "paid_by"]

        labels = {
            "amount": "Amount (কত টাকা)",
            "paid_to": "Paid To (কার কাছে টাকা গেল)",
            "paid_by": "Paid By (কে দিল)",
        }

        widgets = {
            "amount": forms.NumberInput(attrs={"min": 0, "placeholder": "যেমন: 1500"}),
            "paid_to": forms.TextInput(attrs={"placeholder": "Vendor/Person নাম"}),
            "paid_by": forms.TextInput(attrs={"placeholder": "Committee/Collector নাম"}),
        }

    def clean_category_name(self):
        name = (self.cleaned_data.get("category_name") or "").strip()
        if not name:
            raise forms.ValidationError("Category লিখুন")
        return name

    def save(self, commit=True):
        instance = super().save(commit=False)

        # auto set date to today
        instance.date = date.today()

        # set category from typed text
        cat_name = self.cleaned_data["category_name"]
        category = ExpenseCategory.objects.filter(name__iexact=cat_name).first()
        if category is None :
            category = ExpenseCategory.objects.create(name=cat_name)

        instance.category = category

        if commit:
            instance.save()
        return instance

    
    
from django import forms
from .models import Donor

class DonorForm(forms.ModelForm):
    class Meta:
        model = Donor
        fields = ["group", "name", "phone", "address", "outside_area", "expected_amount"]
        labels = {
            "group": "Donor Type (দাতার ধরন)",
            "name": "Donor Name (দাতার নাম)",
            "phone": "Mobile Number (মোবাইল নাম্বার)",
            "address": "Local Area (পাড়া/এলাকার নাম)",
            "outside_area": "Home District (জেলার নাম)",
            "expected_amount": "Expected Amount (প্রত্যাশিত পরিমাণ)",
        }
        widgets = {
          "name": forms.TextInput(attrs={"placeholder": "নাম লিখুন"}),
          "phone": forms.TextInput(attrs={"placeholder": "মোবাইল নম্বর লিখুন"}),
          "address": forms.Textarea(attrs={"rows": 2, "placeholder": "এলাকার নাম লিখুন"}),
          "outside_area": forms.TextInput(attrs={
              "placeholder": "জেলার নাম লিখুন",
              "list": "districtList"   # suggestion এর জন্য
         }),
          "expected_amount": forms.NumberInput(attrs={"min": 0, "placeholder": "টাকার পরিমাণ লিখুন"}),
}

    def clean(self):
        cleaned = super().clean()
        group = cleaned.get("group")
        outside = (cleaned.get("outside_area") or "").strip()

        if group == Donor.OUTSIDE:
            cleaned["outside_area"] = outside or "Nilphamari"
        elif group == Donor.LOCAL:
            cleaned["outside_area"] = ""

        return cleaned


class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        # date auto_now_add, collected_by আমরা view থেকে সেট করবো তাই ফর্মে রাখছি না
        fields = ["donor", "amount", "receipt_no"]
        labels = {
            "donor": "Donor(দাতা)",
            "amount": "Amount (কত টাকা)",
            "receipt_no": "Receipt No (না দিলে Auto হবে)",
        }
        widgets = {
            "amount": forms.NumberInput(attrs={"min": 0}),
        }

class PaymentSuggestForm(forms.Form):
    donor_text = forms.CharField(
        label="Donor(দাতা)",
        widget=forms.TextInput(attrs={
            "placeholder": "দাতার নাম লিখুন (সাজেশন থেকে সিলেক্ট করুন)",
            "list": "donorList"
        })
    )

    amount = forms.DecimalField(
        label="Amount (কত টাকা)",
        min_value=0,
        widget=forms.NumberInput(attrs={"placeholder": "টাকার পরিমাণ লিখুন"})
    )

    receipt_no = forms.CharField(
        label="Receipt No (না দিলে Auto হবে)",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "রসিদ নম্বর (ঐচ্ছিক)"})
    )

    def clean_donor_text(self):
        text = (self.cleaned_data.get("donor_text") or "").strip()

        # Expected format: "... (#23)"
        m = re.search(r"\(#(\d+)\)\s*$", text)
        if not m:
            raise forms.ValidationError("লিস্ট থেকে ডোনার সিলেক্ট করুন")

        donor_id = int(m.group(1))
        donor = Donor.objects.filter(id=donor_id).first()
        if not donor:
            raise forms.ValidationError("ডোনার পাওয়া যায়নি, আবার সিলেক্ট করুন")

        return donor  # Donor object return হবে