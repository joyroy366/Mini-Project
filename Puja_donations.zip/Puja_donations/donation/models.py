from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
import uuid

LOCAL_FIXED_AREA = "Arazikhuka_para"  # এখানে আপনার এলাকার নাম লিখুন


class Donor(models.Model):
    LOCAL = "LOCAL"
    OUTSIDE = "OUTSIDE"
    GROUP_CHOICES = [
        (LOCAL, "Local (এলাকার)"),
        (OUTSIDE, "Outside (বাহিরের)"),
    ]

    group = models.CharField(max_length=10, choices=GROUP_CHOICES)
    name = models.CharField(max_length=150)  # পরিবার/ব্যক্তির নাম
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)

    # শুধু OUTSIDE এর জন্য
    outside_area = models.CharField(max_length=120, blank=True)

    expected_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def clean(self):
        if self.group == self.OUTSIDE and not self.outside_area:
            raise ValidationError({"outside_area": "Outside donor এর জন্য Home District লিখতে হবে."})
        if self.group == self.LOCAL and self.outside_area:
            raise ValidationError({"outside_area": "Local donor হলে outside district খালি রাখুন."})

    @property
    def area(self):
        # Local হলে address-এ লেখা এলাকার নাম দেখাবে (না থাকলে fallback)
        if self.group == self.LOCAL:
            return (self.address or "").strip() or LOCAL_FIXED_AREA
        return (self.outside_area or "").strip()

    def __str__(self):
        return f"{self.name} [{self.group}]"


class Payment(models.Model):
    donor = models.ForeignKey(Donor, on_delete=models.CASCADE, related_name="payments")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateTimeField(auto_now_add=True)

    # login করা user কে collected_by হিসেবে রাখব
    collected_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True
    )

    receipt_no = models.CharField(max_length=20, unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.receipt_no:
            self.receipt_no = uuid.uuid4().hex[:10].upper()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.donor.name} - {self.amount}"
    

class ExpenseCategory(models.Model):
    CATEGORY_CHOICES = [
        ("Food", "Food (খাবার)"),
        ("Decoration", "Decoration (ডেকোরেশন)"),
        ("Light", "Light (লাইট)"),
        ("Pandel", "Pandel (প্যান্ডেল)"),
        ("Priest", "Priest (পুরোহিত)"),
        ("Sound", "Sound (সাউন্ড)"),
    ]

    name = models.CharField(
        max_length=100, choices=CATEGORY_CHOICES, unique=True
    )

    def __str__(self):
        return self.name

class Expense(models.Model):
    date = models.DateField()
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    category = models.ForeignKey(ExpenseCategory, on_delete=models.PROTECT, related_name="expenses")
    paid_to = models.CharField(max_length=150)   # Vendor/Person
    paid_by = models.CharField(max_length=150)   # Collector/Committee
    note = models.CharField(max_length=255, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.date} - {self.category} - {self.amount}"