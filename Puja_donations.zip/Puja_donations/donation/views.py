from decimal import Decimal
from django.contrib.auth.decorators import user_passes_test, login_required

from django.db.models import DecimalField, ExpressionWrapper, F, Sum, Value
from django.db.models.functions import Coalesce
from django.shortcuts import get_object_or_404, redirect, render

from .forms import DonorForm, ExpenseForm, PaymentSuggestForm
from .models import Donor, Payment, Expense, ExpenseCategory


# ---------- Home / Dashboard ----------
def home(request):
    # যদি database এ data না থাকে তাহলে 0 দেখানোর জন্য
    zero = Value(Decimal("0.00"), output_field=DecimalField(max_digits=12, decimal_places=2))

    # মোট donation
    total = Payment.objects.aggregate(t=Coalesce(Sum("amount"), zero))["t"]

    # লোকাল donor donation
    local_total = Payment.objects.filter(donor__group="LOCAL").aggregate(
        t=Coalesce(Sum("amount"), zero)
    )["t"]

    # বাইরের donor donation
    outside_total = Payment.objects.filter(donor__group="OUTSIDE").aggregate(
        t=Coalesce(Sum("amount"), zero)
    )["t"]

    # মোট খরচ
    expense_total = Expense.objects.aggregate(t=Coalesce(Sum("amount"), zero))["t"]

    # বর্তমান balance
    balance = total - expense_total

    donor_count = Donor.objects.count()
    local_count = Donor.objects.filter(group="LOCAL").count()
    outside_count = Donor.objects.filter(group="OUTSIDE").count()

    # recent payment list
    recent_payments = Payment.objects.select_related("donor").order_by("-date")[:10]

    context = {
        "total": total,
        "local_total": local_total,
        "outside_total": outside_total,
        "expense_total": expense_total,
        "balance": balance,
        "donor_count": donor_count,
        "local_count": local_count,
        "outside_count": outside_count,
        "recent_payments": recent_payments,
    }

    return render(request, "donation/home.html", context)


# ---------- Donor List (All / Local / Outside) ----------
def _donor_qs(group=None):
    zero = Value(Decimal("0.00"), output_field=DecimalField(max_digits=12, decimal_places=2))

    qs = (
        Donor.objects.all()
        .annotate(total_paid=Coalesce(Sum("payments__amount"), zero))
        .annotate(
            due=ExpressionWrapper(
                F("expected_amount") - Coalesce(Sum("payments__amount"), zero),
                output_field=DecimalField(max_digits=12, decimal_places=2),
            )
        )
        .order_by("group", "name")
    )

    if group:
        qs = qs.filter(group=group)

    return qs


def donor_list(request):
    donors = _donor_qs()
    return render(request, "donation/donor_list.html", {
        "donors": donors,
        "page_name": "All Donors"
    })


def local_donors(request):
    donors = _donor_qs(Donor.LOCAL)
    return render(request, "donation/donor_list.html", {
        "donors": donors,
        "page_name": "Local Donors"
    })


def outside_donors(request):
    donors = _donor_qs(Donor.OUTSIDE)
    return render(request, "donation/donor_list.html", {
        "donors": donors,
        "page_name": "Outside Donors"
    })


# ---------- Add Donor ----------
def donor_add(request):
    form = DonorForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("donor_list")

    return render(request, "donation/donor_form.html", {"form": form, "title": "Add Donor"})


# ---------- Edit Donor ----------
def donor_edit(request, donor_id):
    donor = get_object_or_404(Donor, id=donor_id)
    form = DonorForm(request.POST or None, instance=donor)
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("donor_list")

    return render(request, "donation/donor_form.html", {"form": form, "title": "Edit Donor"})


# ---------- Delete Donor ----------
def admin_only(user):
    return user.is_superuser

@user_passes_test(admin_only)
def donor_delete(request, donor_id):
    donor = get_object_or_404(Donor, id=donor_id)
    donor.delete()
    return redirect("donor_list")


# ---------- Add Payment (Text + Suggestion) ----------
def payment_add(request):
    donors = Donor.objects.all().order_by("name", "id")

    # donor list থেকে Pay বাটনে ?donor=ID পাঠালে prefill হবে (optional)
    initial = {}
    donor_id = request.GET.get("donor")
    if donor_id and donor_id.isdigit():
        d = Donor.objects.filter(id=int(donor_id)).first()
        if d:
            initial["donor_text"] = f"{d.name} [{d.group}] - {d.phone or '-'} (#${d.id})".replace("#$", "#")

    form = PaymentSuggestForm(request.POST or None, initial=initial)

    if request.method == "POST" and form.is_valid():
        donor = form.cleaned_data["donor_text"]  # Donor object (form clean_donor_text() থেকে আসছে)

        payment = Payment(
            donor=donor,
            amount=form.cleaned_data["amount"],
            receipt_no=form.cleaned_data.get("receipt_no") or "",
        )

        if request.user.is_authenticated:
            payment.collected_by = request.user

        payment.save()
        return redirect("payment_list")

    return render(request, "donation/payment_form.html", {
        "form": form,
        "title": "Add Payment",
        "donors": donors,
    })


# ---------- Payment List (All / Local / Outside) ----------
def _payment_qs(group=None):
    qs = Payment.objects.select_related("donor", "collected_by").order_by("-date", "-id")
    if group:
        qs = qs.filter(donor__group=group)
    return qs


def payment_list(request):
    payments = _payment_qs()
    return render(request, "donation/payment_list.html", {
        "payments": payments,
        "page_name": "All Payments"
    })


def payment_list_local(request):
    payments = _payment_qs(Donor.LOCAL)
    return render(request, "donation/payment_list.html", {
        "payments": payments,
        "page_name": "Local Payments"
    })

# ---------- Payment Receipt ----------
def payment_receipt(request, payment_id):
    payment = get_object_or_404(
        Payment.objects.select_related("donor", "collected_by"),
        id=payment_id
    )

    return render(request, "donation/receipt.html", {
        "payment": payment
    })


def payment_list_outside(request):
    payments = _payment_qs(Donor.OUTSIDE)
    return render(request, "donation/payment_list.html", {
        "payments": payments,
        "page_name": "Outside Payments"
    })


# ---------- Add Expense ----------
def expense_add(request):
    categories = ExpenseCategory.objects.all().order_by("name")

    if request.method == "POST":
        form = ExpenseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/expenses/")
    else:
        form = ExpenseForm()

    return render(request, "donation/expense_form.html", {
        "title": "Add Expense",
        "form": form,
        "categories": categories,
    })


# ---------- Expense List ----------
def expense_list(request):
    expenses = Expense.objects.select_related("category").order_by("-date", "-id")
    return render(request, "donation/expense_list.html", {"expenses": expenses})