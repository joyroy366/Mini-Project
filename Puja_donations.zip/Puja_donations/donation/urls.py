from django.urls import path
from . import views

urlpatterns = [

# Dashboard
path("", views.home, name="home"),

# Donor
path("donors/", views.donor_list, name="donor_list"),
path("donors/local/", views.local_donors, name="local_donors"),
path("donors/outside/", views.outside_donors, name="outside_donors"),
path("donor/add/", views.donor_add, name="donor_add"),
path("donor/edit/<int:donor_id>/", views.donor_edit, name="donor_edit"),
path("donor/delete/<int:donor_id>/", views.donor_delete, name="donor_delete"),

# Local / Outside donor list
path("donors/local/", views.local_donors, name="local_donors"),
path("donors/outside/", views.outside_donors, name="outside_donors"),

# Payment
path("payment/add/", views.payment_add, name="payment_add"),
path("payments/", views.payment_list, name="payment_list"),
path("payments/local/", views.payment_list_local, name="payment_list_local"),
path("payments/outside/", views.payment_list_outside, name="payment_list_outside"),
path("payment/receipt/<int:payment_id>/", views.payment_receipt, name="payment_receipt"),

# Expense
path("expense/add/", views.expense_add, name="expense_add"),
path("expenses/", views.expense_list, name="expense_list"),

]